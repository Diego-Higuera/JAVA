/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package espacios;

import javax.swing.JOptionPane;

/**
 *
 * @author mourelle
 */
public class Espacios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /* Crear una aplicación en Java que pida una cadena de texto al usuario 
        y limpie los espacios innecesarios tanto al principio, como al final, 
        como entre palabras. Una vez limpia la cadena, deberá mostrarse mediante 
        JOptionPane. */
        
        String cadena = JOptionPane.showInputDialog(
                null, 
                "Introduce una cadena", 
                "Quitar espacios", 
                JOptionPane.QUESTION_MESSAGE);
        
        /* Primer paso: quitar espacios al principio y al final. */
        String cadenaLimpia = cadena.trim();
        
        /* Eliminar dos espacios y dejar uno solo. */
        // cadenaLimpia = cadenaLimpia.replace("  ", " ");
        while ( cadenaLimpia.indexOf("  ") != -1 ) {
            cadenaLimpia = cadenaLimpia.replace("  ", " ");
        }
        
        /* Mostrar el resultado. */
        JOptionPane.showMessageDialog(
                null, 
                cadenaLimpia, 
                "Cadena limpia", 
                JOptionPane.INFORMATION_MESSAGE);
        
    } // Final del método main().
    
} // Final de la clase.
