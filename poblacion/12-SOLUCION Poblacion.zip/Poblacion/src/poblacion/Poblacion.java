/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poblacion;

import java.util.Arrays;

/**
 *
 * @author mourelle
 */
public class Poblacion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /* 1) En una ciudad viven un número aleatorio de personas entre 
        (8.000 y 15.000). Suponiendo que las edades de estas personas están 
        comprendidas entre 0 y 100 años, cree un array de 101 posiciones para 
        llevar el recuento de cuántas personas hay en la ciudad de cada una 
        de las posibles edades. */
        int min = 8000;
        int max = 15000;
        int habitantes = (int)Math.floor(Math.random()*(max - min + 1)) + min;
        System.out.println("Población actual: " + habitantes);
        
        int[] edades = new int[101];
        /* Aunque probablemente el lenguaje inicialice todas las posiciones del
        array a ceros, podemos asegurarnos haciéndolo nosotros manualmente. */
        Arrays.fill(edades, 0);
        
        /* 2) En un bucle, recorra uno a uno los habitantes de la ciudad y 
        asígneles a cada uno una edad aleatoria (entre 0 y 100, recuerde). 
        La edad que se obtenga en cada vuelta del bucle, servirá para ir 
        incrementando en una unidad el número de personas de dicha edad que 
        hay en la ciudad (el recuento, recuerde, se llevará en el array que 
        se generó en el paso 1). */
        min = 0;
        max = 100;
        int edad;
        for ( int h=1; h<=habitantes; h++) {
            /* Pregunto la edad del habitante (la genero aleatoriamente) */
            edad = (int)Math.floor(Math.random()*(max - min + 1)) + min;
            /* Incremento el contador de edades de esa edad. */
            edades[edad]++;
        }
        System.out.println(Arrays.toString(edades));

        /* 3) ¿Cuál es la edad media de edad de la población? */
        /* Calculamos la suma de la cantidad de personas por su edad. */
        int suma = 0;
        for ( int e=0; e<=100; e++ ) {
            suma += edades[e] * e;
        }
        float mediaEdad = (float)suma / habitantes;
        System.out.println("Media de edad: " + mediaEdad);
        
        /* 4) ¿Cuál es la edad máxima de los habitantes de la ciudad? ¿Cuántos 
        habitantes hay de dicha edad? */
        /* En el array de edades, empezando por el final, hay que buscar el
        primer índice cuyo valor sea distinto de cero. */
        int edadMaxima = 100;
        while ( edades[edadMaxima] == 0 ) {
            edadMaxima--;
        }
        System.out.println("Edad máxima: " + edadMaxima);
        System.out.println("Habitantes con la edad máxima: " 
                + edades[edadMaxima]);
        
        /* 5) ¿Cuál es la edad mínima de los habitantes de la ciudad? ¿Cuántos 
        habitantes hay de dicha edad? */
        int edadMinima = 0;
        while ( edades[edadMinima] == 0 ) {
            edadMinima++;
        }
        System.out.println("Edad mínima: " + edadMinima);
        System.out.println("Habitantes con la edad minima: " 
                + edades[edadMinima]);
        
        /* 6) ¿Cuál es el número máximo de habitantes de una misma edad? 
        ¿Cuál/cuáles son dichas edad/edades? */
        /* Hay que buscar el valor máximo del array de edades. */
        int maximoMismaEdad = 0;
        for ( int e=0; e<=100; e++ ) {
            if ( edades[e] > maximoMismaEdad ) {
                maximoMismaEdad = edades[e];
            }
        }
        System.out.println("Número máximo de habitantes de una misma edad: " 
                + maximoMismaEdad);
        
        /* Busco las edades que corresponden a este máximo. */
        System.out.println("Correspondiente a las edades:");
        for ( int e=0; e<=100; e++ ) {
            if ( edades[e] == maximoMismaEdad ) {
                System.out.println(e + " años");
            }
        }
        
        /* 7) ¿Cuál es el número mínimo de habitantes de una misma edad? 
        ¿Cuál/cuáles son dichas edad/edades? */
        int minimoMismaEdad = maximoMismaEdad;
        for ( int e=0; e<=100; e++ ) {
            if ( edades[e] < minimoMismaEdad ) {
                minimoMismaEdad = edades[e];
            }
        }
        System.out.println("Número mínimo de habitantes de una misma edad: " 
                + minimoMismaEdad);
        
        /* Busco las edades que corresponden a este máximo. */
        System.out.println("Correspondiente a las edades:");
        for ( int e=0; e<=100; e++ ) {
            if ( edades[e] == minimoMismaEdad ) {
                System.out.println(e + " años");
            }
        }
        
        /* 8) En un posible sufragio, ¿cuántos habitantes habría en el censo 
        electoral? (es decir, cuántos habitantes tienen una edad igual o 
        superior a 18 años? */
        int electores = 0;
        for ( int e=18; e<=100; e++ ) {
            electores += edades[e];
        }
        System.out.println("Electores: " + electores);
        
        /* 9) ¿Hay alguna edad que no esté representada por ningún habitante 
        de la ciudad? (por ejemplo, ningún habitante de la ciudad tiene 20 
        años ni 47 años). Indique cuál/cuáles. */
        boolean bandera = false;
        /* Recorro todas las edades. */
        for ( int e=0; e<=100; e++ ) {
            if ( edades[e] == 0 ) {
                bandera = true;
                break;
            }
        }
        if ( bandera ) {
            System.out.println("Las siguientes edades no están representadas:");
            for ( int e=0; e<=100; e++ ) {
                if ( edades[e] == 0 ) {
                    System.out.println(e + " años");
                }
            }
        } else {
            System.out.println("Todas las edades están representadas.");
        }

    } // Final del método main().
    
} // Final de la clase.
