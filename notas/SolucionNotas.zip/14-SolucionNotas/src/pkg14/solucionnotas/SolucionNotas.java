/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg14.solucionnotas;

import javax.swing.JOptionPane;

/**
 *
 * @author mourelle
 */
public class SolucionNotas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /* Crear un programa en java (proyecto EjercicioNotas) que almacene las 
        notas de tres alumnos:
        
            Lorenzo
                    Teoría: 7
                    Práctica: 4
                    Evaluación continua: 8
            Alfredo
                    Teoría: 5
                    Práctica: 6
                    Evaluación continua: 7
            Maribel
                    Teoría: 9
                    Práctica: 10
                    Evaluación continua: 10
        
        Organice la información en dos arrays: uno con los nombres de los 
        alumnos y otro de dos dimensiones con sus notas. */

        /* En un caso real, estos arrays se generarán a partir de leer la
        información en una base de datos. Por lo tanto, el programa tiene que 
        ser genérico y no depender de un número fijo de alumnos. */
        
        // -------------------------------------------------------------------
        
        /* Crear el array de nombres. */
        String[] nombres = {"Lorenzo", "Alfredo", "Maribel"};
        
        /* El array de las notas tiene dos dimensiones. La primera dimensión
        corresponderá el índice del alumno y la seguna a las notas, respectiva-
        mente, teoría, práctica y evaluación continua. */
        int[][] notas = {
            {7, 4, 8},
            {5, 6, 7},
            {9, 10, 10}
        };
        
        // -------------------------------------------------------------------

        /* Se me antoja que hay algunas informaciones que necesito conocer para
        aplicar en todo el proyecto, como son el número de alumnos y la nota
        final de cada alumno. Las voy a calcular en primer lugar, para poder
        utilizarlas más adelante. */
        int numeroAlumnos = nombres.length;
        
        /* Para las notas finales creo un nuevo array. */
        float notasFinales[];
        notasFinales = new float[numeroAlumnos];

        /* Recorro todos los alumnos. */
        for ( int i=0; i<numeroAlumnos; i++ ) {
            /* Extraigo cada una de las notas. */
            int teoria = notas[i][0];
            int practica =  notas[i][1];
            int evaluacion = notas[i][2];
            /* Cálculo de la nota final. */
            float notaFinal = 0.7f * (teoria + practica) / 2 + evaluacion * 0.3f;
            /* Inserto la nota en el array. */
            notasFinales[i] = notaFinal;
        }
        
        /* 1. Muestre por pantalla la información de cada alumno: nombre, sus 
        distintas notas y la nota final, que estará compuesta en un 70% por el 
        promedio de sus notas teórica y práctica y en un 30 % por la nota de 
        evaluación continua. */
        
        /* Vamos a mostrar una ficha por cada uno de los alumnos. */
        for ( int i=0; i<numeroAlumnos; i++ ) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Notas del alumno " + nombres[i] + "\n" + 
                            "Teoría: " + notas[i][0] + "\n" +
                            "Práctica: " + notas[i][1] + "\n" +
                            "Evaluación continua: " + notas[i][2] + "\n" +
                            "Nota final: " + notasFinales[i], 
                    "Resumen de notas", 
                    JOptionPane.INFORMATION_MESSAGE);
        }        

        /* 2. ¿Cuál es la media de las notas teóricas de todos distintos 
        alumnos? ¿Cuál la media de las notas prácticas? ¿Cuál la media de las 
        notas de evaluación continua? */
        
        /* Necesitamos tres variables para hacer el sumatorio de las notas de
        teoría, práctica y ec. Luego, recorremos el array de notas haciendo la
        suma de cada categoría. Al salir del array, puedo calcular la media
        dividiendo entre el número de alumnos. */
        int sumaT = 0, sumaP = 0, sumaEC = 0;
        for ( int i=0; i<numeroAlumnos; i++ ) {
            sumaT += notas[i][0];
            sumaP += notas[i][1];
            sumaEC += notas[i][2];
        }
        /* Una vez hecha la suma, calculamos el promedio diviendo entre el
        número de alumnos. Cuando Java divide dos números enteros da por sentado
        que el resultado de la división también debe ser entero. Por eso, es
        necesario convertir a tipo float para no perder los decimales. */
        float promedioT = (float) sumaT / numeroAlumnos;
        float promedioP = (float) sumaP / numeroAlumnos;
        float promedioEC = (float) sumaEC / numeroAlumnos;
        
        /* Sólo nos queda pintar los resultados. */
        JOptionPane.showMessageDialog(
                null, 
                "Notas medias de la clase:\n" +
                        "Teoría: " + promedioT + "\n" +
                        "Práctica: " + promedioP + "\n" + 
                        "Evaluación continua: " + promedioEC, 
                "Notas medias", 
                JOptionPane.INFORMATION_MESSAGE);
        
        /* 3. ¿Qué alumno tiene la nota final más alta? (o alumnos). */
        
        /* Creamos una variable donde vamos a ir almacenando el valor de la nota
        más alta a medida que vayamos comparando con las notas finales y
        encontremos un valor mayor. Es buena idea inicializar a cero, ya que es
        la nota más baja posible. */
        float notaMasAlta = 0;
        for ( int i=0; i<numeroAlumnos; i++ ) {
            if ( notasFinales[i] > notaMasAlta ) {
                notaMasAlta = notasFinales[i];
            }
        }
        
        /* Salgo del bucle sabiendo cuál es la nota más alta de la clase. Pero
        tengo que averiguar ahora, a qué alumnos corresponde esa nota. Vamos a
        construir un mensaje donde vamos a ir añadiendo a todos los alumnos que
        encontremos que coincidan con la nota más alta. */
        String mensaje = "Alumnos con la nota más alta de " + notaMasAlta + "\n";
        /* Ahora, recorremos el array de notas más altas para ver qué registro
        coincide con dicha nota. */
        for ( int i=0; i<numeroAlumnos; i++ ) {
            if ( notasFinales[i] == notaMasAlta ) {
                mensaje += nombres[i] + "\n";
            }
        }
        
        /* Mostramos el mensaje en un JOptionPane. */
        JOptionPane.showMessageDialog(
                null, 
                mensaje, 
                "Nota más alta", 
                JOptionPane.INFORMATION_MESSAGE);
        
        /* 4. ¿Ha suspendido algún alumno (nota final menor que cinco)? En caso 
        afirmativo, ¿qué alumnos han suspendido? El procedimiento es igual que
        en el apartado anterior. Ya tengo el criterio, que es ser menor que 5 y
        lo que quedaría es recorrer el array de notas finales de los alumnos 
        para construir un mensaje que muestre una lista de los suspensos. Pero
        tengo un problema. ¿Qué sucede si ningún alumno suspende? Que aparece el
        mensaje en blanco. En su lugar debería aparecer un mensaje explicando
        que no hay ningún suspenso. Para solucionarlo, voy a llevar un contador
        de suspensos. A la salida del bucle, si el contador me dice que hay cero
        suspensos pondré un mensaje y si no, pondré el otro.*/
        String suspensos = "Alumnos que han suspendido:\n";
        int cuentaSuspensos = 0;
        for ( int i=0; i<numeroAlumnos; i++ ) {
            /* Comprobar si algún alumno ha suspendido. */
            if ( notasFinales[i] < 5 ) {
                suspensos += nombres[i] + "\n";
                cuentaSuspensos++;
            }
        }
        
        if ( cuentaSuspensos == 0 ) {
            JOptionPane.showMessageDialog(
                    null, 
                    "No hay ningún alumno suspenso.", 
                    "Suspensos", 
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(
                    null, 
                    suspensos, 
                    "Suspensos", 
                    JOptionPane.INFORMATION_MESSAGE);
        }
        
        /* 5. ¿De qué color era el caballo blanco de Santiago? */
        JOptionPane.showMessageDialog(
                null, 
                "Santiago no tenía caballo. Se lo robaron junto al carro de "
                        + "Manolo Escobar. Si alguien lo ve, que llame al "
                        + "teléfono 555 123 456", 
                "Santiago", 
                JOptionPane.INFORMATION_MESSAGE);
        
        
        


        
    } // Final del main
    
} // Final de la clase
