/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucioninmobiliaria;

/**
 *
 * @author mourelle
 */
public final class Piso extends Inmueble {
    
    /* Atributos. */
    private final int metrosUtiles;
    private final int metrosConstruidos;
    private final int anoConstruccion;
    private final int numeroHabitaciones;
    
    
    /* Constructor por defecto. */
    public Piso() {
        super();
        metrosUtiles = 0;
        metrosConstruidos = 0;
        anoConstruccion = 0;
        numeroHabitaciones = 0;
    }
    
    /* Constructor sobrecargado. */
    public Piso( Vendedor vendedor, String ciudad, String direccion, 
            int precio, int rebaja, TipoOperacion tipoOperacion, 
            int metrosUtiles, int metrosConstruidos, int anoConstruccion,
            int numeroHabitaciones) {
        super(vendedor, ciudad, direccion, precio, rebaja, tipoOperacion);
        this.metrosUtiles = metrosUtiles;
        this.metrosConstruidos = metrosConstruidos;
        this.anoConstruccion = anoConstruccion;
        this.numeroHabitaciones = numeroHabitaciones;
    }
    
    
    /* Accesores. */

    public int getMetrosUtiles() {
        return metrosUtiles;
    }

    public int getMetrosConstruidos() {
        return metrosConstruidos;
    }

    public int getAnoConstruccion() {
        return anoConstruccion;
    }

    public int getNumeroHabitaciones() {
        return numeroHabitaciones;
    }
    
    
    /* Método toString(). */
    @Override
    public String toString() {
        String resultado = super.toString();
        resultado += "Metros útiles: " + metrosUtiles + "\n";
        resultado += "Metros construidos: " + metrosConstruidos + "\n";
        resultado += "Año de construcción: " + anoConstruccion + "\n";
        resultado += "Número de habitaciones: " + numeroHabitaciones + "\n";
        resultado += "Precio por metro cuadrado: " + precioM2();
        
        return resultado;
    }
    
    
    /* Funciones adicionales. */
    public float precioM2() {
        return (float)super.getPrecio() / (float)metrosConstruidos;
    }
    
} // Final de la clase.
