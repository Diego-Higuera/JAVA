/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucioninmobiliaria;

/**
 *
 * @author mourelle
 */
public class SolucionInmobiliaria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /* Damos a luz un vendedor. */
        Vendedor yaiza = new Vendedor("Yaiza","González","12345678Z");
        /* Obtenemos su información. */
        System.out.println(yaiza.toString());
        
        /* Pongo en venta un piso. */
        Piso piso1 = new Piso(yaiza,"Madrid","C/ Pez, 123",200000,10000,
                TipoOperacion.VENTA,150,165,1999,3);
        System.out.println(piso1.toString());
        
    } // Final del método main().
    
} // Final de la clase.
