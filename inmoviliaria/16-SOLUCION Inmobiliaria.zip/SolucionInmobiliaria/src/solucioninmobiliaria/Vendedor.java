/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucioninmobiliaria;

/**
 *
 * @author mourelle
 */
public final class Vendedor extends Persona {
    
    /* Atributos añadidos. */
    private final String dni;
    
    
    /* Constructor por defecto. */
    public Vendedor() {
        super();
        dni = "";
    }
    
    /* Constructor sobrecargado. */
    public Vendedor( String nombre, String apellidos, String dni ) {
        super(nombre, apellidos);
        this.dni = dni;
    }
    
    
    /* Accesores. */
    public String getDni() {
        return dni;
    }
    
    
    /* Método toString(). */
    @Override
    public String toString() {
        String resultado = super.toString();
        resultado += "DNI: " + dni;
        
        return resultado;
    }
    
} // Final de la clase
