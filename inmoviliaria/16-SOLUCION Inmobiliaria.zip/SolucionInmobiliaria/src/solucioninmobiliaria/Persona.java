/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucioninmobiliaria;

/**
 *
 * @author mourelle
 */
public abstract class Persona {
    
    /* Atributos. */
    private final String nombre;
    private final String apellidos;
    
    
    /* Constructor por defecto. Solamente por buenas prácticas. No lo vamos a
    utilizar nunca. */
    public Persona() {
        nombre = "";
        apellidos = "";
    }
    
    /* Constructor sobrecargado. */
    public Persona( String nombre, String apellidos ) {
        this.nombre = nombre;
        this.apellidos = apellidos;
    }
    
    
    /* Accesores. */
    public String getNombre() {
        return nombre;
    }
    
    public String getApellidos() {
        return apellidos;
    }
    
    
    /* Método toString(). */
    @Override
    public String toString() {
        String resultado = "Nombre: " + nombre + "\n";
        resultado += "Apellidos: " + apellidos + "\n";
        
        return resultado;
    }
    
} // Final de la clase.
