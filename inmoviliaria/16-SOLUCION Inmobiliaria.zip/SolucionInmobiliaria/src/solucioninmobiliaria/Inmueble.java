/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucioninmobiliaria;

/**
 *
 * @author mourelle
 */
public abstract class Inmueble {
    
    /* Atributos. */
    private final Vendedor vendedor;
    private final String ciudad;
    private final String direccion;
    private int precio;
    private int rebaja;
    private TipoOperacion tipoOperacion;
    
    
    /* Constructor por defecto. */
    public Inmueble() {
        vendedor = null;
        ciudad = "";
        direccion = "";
        precio = 0;
        rebaja = 0;
        tipoOperacion = null;
    }
    
    /* Constructor sobrecargado. */
    public Inmueble( Vendedor vendedor, String ciudad, String direccion, 
            int precio, int rebaja, TipoOperacion tipoOperacion) {
        this.vendedor = vendedor;
        this.ciudad = ciudad;
        this.direccion = direccion;
        this.precio = precio;
        this.rebaja = rebaja;
        this.tipoOperacion = tipoOperacion;
    }
    
    
    /* Accesores. */
    public Vendedor getVendedor() {
        return vendedor;
    }
    public String getCiudad() {
        return ciudad;
    }
    public String getDireccion() {
        return direccion;
    }
    
    public int getPrecio() {
        return precio;
    }
    public void setPrecio( int precio ) {
        this.precio = precio;
    }
    
    public int getRebaja() {
        return rebaja;
    }
    public void setRebaja( int rebaja ) {
        this.rebaja = rebaja;
    }
    
    public TipoOperacion getTipoOperacion() {
        return tipoOperacion;
    }
    public void setTipoOperacion( TipoOperacion tipoOperacion ) {
        this.tipoOperacion = tipoOperacion;
    }
    
    
    /* Método toString() */
    @Override
    public String toString() {
        String resultado = "Vendedor: " + vendedor.getNombre() + " " 
                + vendedor.getApellidos() + "\n";
        resultado += "Ciudad: " + ciudad + "\n";
        resultado += "Dirección: " + direccion + "\n";
        resultado += "Precio: " + precio + "\n";
        resultado += "Rebaja: " + rebaja + "\n";
        resultado += "Tipo de operación: " + tipoOperacion + "\n";
        
        return resultado;
    }
    
    
} // Final de la clase.
