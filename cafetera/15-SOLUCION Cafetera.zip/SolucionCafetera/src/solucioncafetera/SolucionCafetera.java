/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucioncafetera;

/**
 *
 * @author mourelle
 */
public class SolucionCafetera {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /* Instanciar una cafetera con el constructor por defecto. */
        Cafetera miCafetera = new Cafetera();
        
        /* Preparar un café con 500ml de agua y 10 cucharadas. */
        miCafetera.prepararCafe(500, 10);
        
        /* Servir una taza de 200 y otra de 150. */
        miCafetera.servirTaza(200);
        miCafetera.servirTaza(150);
        
        /* Mostrar la información con el método toString. */
        System.out.println(miCafetera.toString());
        
        /* Vaciamos la cafetera. */
        miCafetera.vaciarCafetera();
        
        /* Nueva cafetera con capacidad de 700, agua 700 y café 8. */
        Cafetera otraCafetera = new Cafetera(700,8,700);
        
        /* Preparar el café. */
        otraCafetera.prepararCafe();
        
        /* Servir una taza de 250. */
        otraCafetera.servirTaza(250);
        
        /* Mostrar la información. */
        System.out.println(otraCafetera.toString());

    } // Final del método main().
    
} // Final de la clase.
