/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucioncafetera;

import javax.swing.JOptionPane;

/**
 *
 * @author mourelle
 */
public class Cafetera {
    
    /* Atributos o campos de la clase. */
    private final int capacidadMaxima; // En centímetros cúbicos o mililitros.
    private int cantidadActual;  // En las mismas medidas.
    private int cafeMolido; // En cucharadas entre 0 y 10.
    private int agua; // También en mililitros.
    private float concentracion;
    
    
    /* Constructor predeterminado. */
    public Cafetera() {
        capacidadMaxima = 1000;
        cantidadActual = 0;
        cafeMolido = 0;
        agua = 0;
        concentracion = 0.0f;
    }
    
    /* Constructor sobrecargado. */
    public Cafetera( int capacidadMaxima, int cafeMolido, int agua ) {
        this.capacidadMaxima = capacidadMaxima;
        /* Si el café o el agua son menores que cero, lo enrasamos a cero. Si
        son mayores que el máximo (10 para el café), capacidadMaxima para el
        agua) lo enrasamos a dicho valor máximo. */
        this.cafeMolido = restringir(cafeMolido,0,10);
        this.agua = restringir(agua,0,this.capacidadMaxima);
        
        this.cantidadActual = 0;
        this.concentracion = 0.0f;
    }
    
    
    /* Métodos accesores. */
    public int getCapacidadMaxima() {
        return capacidadMaxima;
    }
    /* No hay setter porque el campo es final. */
    
    public int getCantidadActual() {
        return cantidadActual;
    }
    public void setCantidadActual( int cantidadActual ) {
        /* Restricción: no puede superar la capacidad máxima ni puede ser menor
        que cero. */
        this.cantidadActual = restringir(cantidadActual,0,capacidadMaxima);
    }
    
    public int getCafeMolido() {
        return cafeMolido;
    }
    public void setCafeMolido( int cafeMolido ) {
        /* Restricción: entre 0 y 10. */
        this.cafeMolido = restringir(cafeMolido,0,10);
    }
    
    public int getAgua() {
        return agua;
    }
    public void setAgua( int agua ) {
        /* Entre 0 y capacidad máxima. */
        this.agua = restringir(agua,0,capacidadMaxima);
    }
    
    public float getConcentracion() {
        return concentracion;
    }
    public void setConcentracion( float concentracion ) {
        this.concentracion = concentracion;
    }
    
    
    /* Método toString(). */
    @Override
    public String toString() {
        String resultado = "CAFETERAS LA PAVA\n";
        resultado += "-----------------\n";
        resultado += "Capacidad máxima: " + capacidadMaxima + " ml\n";
        resultado += "Cantidad de café: " + cantidadActual + " ml\n";
        resultado += "Café molido: " + cafeMolido + " cucharadas\n";
        resultado += "Agua: " + agua + " ml\n";
        resultado += "Concentración: " + concentracion;
        
        return resultado;
    }
    
    
    /* Métodos específicos. */
    
    /* Un método para determinar si un valor se encuentra dentro de un rango
    determinado. Devuelve el mínimo si el valor es menor que dicho mínimo,
    el máximo si es mayor que dicho máximo o el valor concreto si está en el
    rango.
        Parámetros de entrada:
        int valor: el valor que queremos analizar.
        int minimo: el valor mínimo del rango.
        int maximo: el valor máximo del rango.
    
        Devuelve:
        Un entero entre el mínimo y el máximo ambos incluidos.
    */
    public final int restringir(int valor, int minimo, int maximo) {
        if ( valor > maximo ) {
            return maximo;
        } else if ( valor < 0 ) {
            return 0;
        } else {
            return valor;
        }
    }
    
    public int pedirValor(int valor, int minimo, int maximo, 
            String mensaje, String titulo) {

        while ( valor == 0 ) {
            valor = restringir(Integer.parseInt(
                    JOptionPane.showInputDialog(
                            null, 
                            mensaje, 
                            titulo, 
                            JOptionPane.QUESTION_MESSAGE)),minimo,maximo);
        }
        
        return valor;
            
        /* Lo divido en los pasos para que sea más entendible. Hay que
        obtener un valor de JOptionPane, hay que convertirlo a entero y
        hay que comprobar que esté en el rango. */
        /* String valorCadena = JOptionPane.showInputDialog(
                        null, 
                        mensaje, 
                        "Café molido", 
                        JOptionPane.QUESTION_MESSAGE); */
        /* Convierto a entero. */
        /* int valorEntero = Integer.parseInt(valorCadena); */
        /* Paso por el filtro de la restricción. */
        /* cafeMolido = restringir(valorEntero,0,10); */
        
    }

    public void vaciarCafetera() {
        cantidadActual = 0;
        cafeMolido = 0;
        agua = 0;
        concentracion = 0.0f;
    }
    
    public void prepararCafe() {
        /* Vaciar la jarra con el café preparado que pueda haber. */
        cantidadActual = 0;
        
        cafeMolido = pedirValor(cafeMolido,0,10,
                "Inserte la cantidad de café molido","Café molido");
        
        agua = pedirValor(agua,0,capacidadMaxima,
                "Inserte la cantidad de agua","agua");
        
        /* Preparamos el café. */
        cantidadActual = agua;
        concentracion = (float)cafeMolido / (float)agua;
        
        /* Restablecemos agua y café molido. */
        cafeMolido = 0;
        agua = 0;
    }
    
    public void prepararCafe( int agua, int cafeMolido ) {
        /* Restringir ambos valores al rango. */
        this.agua = restringir(agua,0,capacidadMaxima);
        this.cafeMolido = restringir(cafeMolido,0,10);
        /* O, incluso, llamar a los setter correspondientes. */
        
        prepararCafe();
    }
    
    public void servirTaza( int cantidad ) {
        int servir = restringir(cantidad,0,cantidadActual);
        cantidadActual -= servir;
        
        JOptionPane.showMessageDialog(
                null, 
                "Se ha servido una taza de " + servir + " ml", 
                "Servir taza", 
                JOptionPane.INFORMATION_MESSAGE);
    }
    
} // Fin de la clase.
