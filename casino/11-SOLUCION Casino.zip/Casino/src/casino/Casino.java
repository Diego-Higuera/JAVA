/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casino;

import java.util.Arrays;

/**
 *
 * @author mourelle
 */
public class Casino {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /* 1) Cree un array con 37 posiciones para hacer un recuento de la 
        frecuencia con la que aparecen los distintos números de la ruleta 
        (del 0 al 36). */
        int[] ruleta = new int[37];
        
        /* El array constituye un conjunto de contadores de cuántas veces
        aparece cada número. Para hacer estos contadores debemos inicializar
        a cero todas las posiciones del array. */
        Arrays.fill(ruleta, 0);
        
        /* ¿Pero cómo lo haría si no recuerdo la existencia de este método o si
        no existiera en mi lenguaje de programación. */
        for ( int i=0; i<=36; i++ ) {
            /* Inicializar a cero la posición correspondiente. */
            ruleta[i] = 0;
        }

        // System.out.println(Arrays.toString(ruleta));
        
        int tiradas = 1000000;

        /* 2) Simule la realización de 500 tiradas de prueba. Con un bucle 
        recorra las 500 tiradas y genere en cada una de ellas un valor 
        aleatorio entre 0 y 36. En cada tirada, el número aleatorio obtenido 
        se utilizará para ir incrementando el valor almacenádo en el índice 
        del mismo número del array del paso anterior. De esta manera, se irá 
        realizando un recuento de las veces que aparece cada número. */
        int min = 0;
        int max = 36;
        int aleatorio;
        for ( int t=1; t<=tiradas; t++ ) {
            /* Genero un número aleatorio. */
            aleatorio = (int)Math.floor(Math.random()*(max - min + 1)) + min;
            /* Incrementar el valor de la posición del array en el índice
            aleatorio. */
            ruleta[aleatorio]++;
        }

        System.out.println(Arrays.toString(ruleta));
        
        /* 3) ¿Cuál es el o los números que han aparecido más veces? ¿Cuáles 
        son los que menos? */
        
        /* Lo desgloso en primero conocer cuál es el valor máximo de veces que
        ha salido un número de la ruleta y segundo saber qué números son los 
        que han salido esa cantidad de veces. */
        int maximo = 0;
        for ( int i=0; i<=36; i++ ) {
            if ( ruleta[i] > maximo ) {
                maximo = ruleta[i];
            }
        }
        
        System.out.println("El valor máximo de veces que ha salido un "
                + "número es: " + maximo);
        
        /* ¿Qué numeros han salido esa cantidad de veces? */
        System.out.println("Correspondiente a los números: ");
        for ( int i=0; i<=36; i++ ) {
            if ( ruleta[i] == maximo ) {
                System.out.println("El número " + i);
            }
        }
        
        /* Para los números que han salido menos veces, el proceso es el mismo.
        */
        int minimo = maximo;
        for ( int i=0; i<=36; i++ ) {
            if ( ruleta[i] < minimo ) {
                minimo = ruleta[i];
            }
        }
        
        System.out.println("El valor mínimo de veces que ha salido un "
                + "número es: " + minimo);
        
        /* ¿Qué numeros han salido esa cantidad de veces? */
        System.out.println("Correspondiente a los números: ");
        for ( int i=0; i<=36; i++ ) {
            if ( ruleta[i] == minimo ) {
                System.out.println("El número " + i);
            }
        }
        
        /* 4) ¿Cuál es el valor promedio de apariciones de cada número? (por 
        ejemplo, el 0 ha aparecido un 2.5% de las tiradas. */
        float promedio;
        for ( int i=0; i<=36; i++ ) {
            /* Calculamos el promedio. Ojo que si todos los operandos son 
            enteros, Java devolverá un entero en forma de float. Para resolver
            este problema, convertimos a float cualquiera de los valores de la
            expresión. */
            promedio = (float)ruleta[i] * 100 / tiradas;
            System.out.println("Promedio del número " + i + ": " 
                    + promedio + "%");
        }

        /* ¿El promedio del cero está por encima o por debajo de la media
        global? Podemos calcularlo como el promedio de veces que sale un número
        o como el porcentaje de veces que sale dicho número. */
        // float vecesMedioGlobal = (float)tiradas / 37;
        // float vecesCero = ruleta[0];
        float mediaGlobal = (float)100 / 37;
        System.out.println("El promedio global es: " + mediaGlobal + "%");
        float mediaCero = (float)ruleta[0] * 100 / tiradas;
        if ( mediaCero == mediaGlobal ) {
            System.out.println("El 0 está justo en el promedio");
        } else if ( mediaCero > mediaGlobal ) {
            System.out.println("El 0 está por encima del promedio");
        } else {
            System.out.println("El 0 está por debajo del promedio");
        }
        
        
        


    } // Final del método main().
    
} // Final de la clase.
