/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucionfutbol;

import javax.swing.JOptionPane;

/**
 *
 * @author mourelle
 */
public final class Entrenador extends SeleccionFutbol {
    
    /* Atributos adicionales. */
    private final int idFederacion;
    
    
    /* Constructor predeterminado. */
    public Entrenador() {
        super();
        idFederacion = 0;
    }
    
    public Entrenador( int id, String nombre, String apellidos, int edad, 
            int idFederacion ) {
        super( id, nombre, apellidos, edad );
        this.idFederacion = idFederacion;
    }
    
    
    /* Accesores. */
    public int getIdFederacion() {
        return idFederacion;
    }
    
    
    /* Método toString() */
    @Override
    public String toString() {
        String resultado = super.toString();
        resultado += "Id de federación: " + idFederacion;
        
        return resultado;
    }
    
    
    /* Otros métodos. */
    @Override
    public void concentrarse() {
        JOptionPane.showMessageDialog(
                null, 
                "El entrenador " + getNombre() + " " + 
                        getApellidos() + " está concentrado." , 
                "Entrenador concentrado", 
                JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    public void viajar() {
        JOptionPane.showMessageDialog(
                null, 
                "El entrenador " + getNombre() + " " + 
                        getApellidos() + " está viajando." , 
                "Entrenador viajando", 
                JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    public void entrenar() {
        JOptionPane.showMessageDialog(
                null, 
                "El entrenador " + getNombre() + " " + 
                        getApellidos() + " está entrenando." , 
                "Entrenador entrenando", 
                JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    public void jugarPartido() {
        JOptionPane.showMessageDialog(
                null, 
                "El entrenador " + getNombre() + " " + 
                        getApellidos() + " está dirigiendo un partido." , 
                "Entrenador dirigiendo un partido", 
                JOptionPane.INFORMATION_MESSAGE);
    }

    public void planificarEntrenamiento() {
        JOptionPane.showMessageDialog(
                null, 
                "El entrenador " + getNombre() + " " + 
                        getApellidos() + " está planificando "
                                + "un entrenamiento." , 
                "Entrenador planificando un entrenamiento", 
                JOptionPane.INFORMATION_MESSAGE);
    }
    
}
