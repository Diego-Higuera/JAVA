/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucionfutbol;

import javax.swing.JOptionPane;

/**
 *
 * @author mourelle
 */
public final class Masajista extends SeleccionFutbol {

    /* Atributos adicionales. */
    private final String titulacion;
    private final int aniosExperiencia;
    
    
    /* Constructor por defecto. */
    public Masajista() {
        super();
        titulacion = "";
        aniosExperiencia = 0;
    }
    
    /* Constructor sobrecargado. */
    public Masajista( int id, String nombre, String apellidos, int edad, 
            String titulacion, int aniosExperiencia) {
        super( id, nombre, apellidos, edad );
        this.titulacion = titulacion;
        this.aniosExperiencia = aniosExperiencia;
    }
    
    
    /* Accesores. */
    public String getTitulacion() {
        return titulacion;
    }
    
    public int getAniosExperiencia() {
        return aniosExperiencia;
    }
    
    
    /* Método toString(). */
    @Override
    public String toString() {
        String resultado = super.toString();
        resultado += "Titulación: " + titulacion + "\n";
        resultado += "Años de experiencia: " + aniosExperiencia;
        
        return resultado;
    }
    
    
    /* Otros métodos. */
    @Override
    public void concentrarse() {
        JOptionPane.showMessageDialog(
                null, 
                "El masajista " + getNombre() + " " + 
                        getApellidos() + " está concentrado." , 
                "Masajista concentrado", 
                JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    public void viajar() {
        JOptionPane.showMessageDialog(
                null, 
                "El masajista " + getNombre() + " " + 
                        getApellidos() + " está viajando." , 
                "Masajista viajando", 
                JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    public void entrenar() {
        JOptionPane.showMessageDialog(
                null, 
                "El masajista " + getNombre() + " " + 
                        getApellidos() + " está asistiendo un entrenamiento." , 
                "Masajista asistiendo un entrenamiento", 
                JOptionPane.INFORMATION_MESSAGE);
    }

    @Override
    public void jugarPartido() {
        JOptionPane.showMessageDialog(
                null, 
                "El masajista " + getNombre() + " " + 
                        getApellidos() + " está asistiendo un partido." , 
                "Masajista asistiendo un partido", 
                JOptionPane.INFORMATION_MESSAGE);
    }

    public void darMasaje() {
        JOptionPane.showMessageDialog(
                null, 
                "El masajista " + getNombre() + " " + 
                        getApellidos() + " está dando un masaje." , 
                "Masajista dando un masaje", 
                JOptionPane.INFORMATION_MESSAGE);
    }
    
    /* Nos quedamos con la pena de saber a quién está dando un masaje el
    masajista. Para ello, tendremos que hacer un método sobrecargado que reciba
    como parámetro el jugador al que está asistiendo. */
    public void darMasaje( Futbolista futbolista ) {
        JOptionPane.showMessageDialog(
                null, 
                "El masajista " + getNombre() + " " + 
                        getApellidos() + " está dando un masaje al jugador " + 
                        futbolista.getNombre() + " " + 
                        futbolista.getApellidos() , 
                "Masajista dando un masaje", 
                JOptionPane.INFORMATION_MESSAGE);
    }
    
}
