/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucionfutbol;

/**
 *
 * @author mourelle
 */
public class SolucionFutbol {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /* Implemento un futbolista. */
        Futbolista futbolista1 = new Futbolista( 12345, "Mariano", 
                "Valeunduro", 43, 16, "Defensa" );
        System.out.println(futbolista1.toString());
        
        /* Y le pongo a entrenar. */
        futbolista1.entrenar();
        
        /* Creo un masajista. */
        Masajista masajista1 = new Masajista( 23456, "Manolo", "Lesiona", 33, 
                "Parvulitos", 1 );
        System.out.println(masajista1.toString());
        /* Muestro su información. */
        
        /* Le pongo a dar un masaje al futbolista1. */
        masajista1.darMasaje(futbolista1);
        
        /* Vamos a dar un masaje a un nuevo jugador que vamos a crear de forma
        anónima. */
        masajista1.darMasaje( new Futbolista( 34567, "Kepa", "Quete", 
                22, 7, "Delantero") );
        
    } // Final del método main().
    
} // Final de la clase.
