/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucionfutbol;

/**
 *
 * @author mourelle
 */
public final class Futbolista extends SeleccionFutbol {
    
    /* Atributos */
    private int dorsal;
    private String demarcacion;
    
    
    /* Constructor por defecto. */
    public Futbolista() {
        super();
        dorsal = 0;
        demarcacion = "";
    }

    public Futbolista(int id, String nombre, String apellidos, int edad, 
            int dorsal, String demarcacion) {
        super(id, nombre, apellidos, edad);
        this.dorsal = dorsal;
        this.demarcacion = demarcacion;
    }
    
    
    /* Accesores. */
    public int getDorsal() {
        return dorsal;
    }

    public void setDorsal(int dorsal) {
        this.dorsal = dorsal;
    }

    public String getDemarcacion() {
        return demarcacion;
    }

    public void setDemarcacion(String demarcacion) {
        this.demarcacion = demarcacion;
    }
    
    /* Método toString(). */
    @Override
    public String toString() {
        String resultado = super.toString();
        resultado += "Dorsal: " + dorsal + "\n";
        resultado += "Demarcación: " + demarcacion;
        
        return resultado;
    }

    
    /* Métodos abstractos. */
    @Override
    public void concentrarse() {
        System.out.println("El jugador " + getNombre() + " " + getApellidos() 
                + " está concentrado.");
    }

    @Override
    public void viajar() {
        System.out.println("El jugador " + getNombre() + " " + getApellidos() 
                + " está viajando.");
    }

    @Override
    public void entrenar() {
        System.out.println("El jugador " + getNombre() + " " + getApellidos() 
                + " está entrenando.");
    }

    @Override
    public void jugarPartido() {
        System.out.println("El jugador " + getNombre() + " " + getApellidos() 
                + " está jugando un partido.");
    }
    
    public void entrevista() {
        System.out.println("El jugador " + getNombre() + " " + getApellidos() 
                + " está dando una entrevista.");
    }
    
}
