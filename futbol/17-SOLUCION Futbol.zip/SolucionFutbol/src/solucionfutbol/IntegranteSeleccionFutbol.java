/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package solucionfutbol;

/**
 *
 * @author mourelle
 */
public interface IntegranteSeleccionFutbol {
    
    /* Métodos abstractos. */
    public void concentrarse();
    public void viajar();
    public void entrenar();
    public void jugarPartido();
    
}
